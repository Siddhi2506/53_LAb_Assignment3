# 3d_model_car > 2025-04-27 11:27pm
https://universe.roboflow.com/siddhis-workspace/3d_model_car-ohghc

Provided by a Roboflow user
License: CC BY 4.0

